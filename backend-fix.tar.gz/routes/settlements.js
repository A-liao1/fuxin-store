"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const models_1 = __importDefault(require("../models"));
const router = express_1.default.Router();
const { Settlement, Purchase, Sale } = models_1.default;
// 获取所有结算记录
router.get('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const settlements = yield Settlement.findAll();
        res.json(settlements);
    }
    catch (error) {
        res.status(500).json({ error: '获取结算记录失败' });
    }
}));
// 创建结算记录
router.post('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { bill_type, bill_id, settlement_date, amount, payment_method } = req.body;
        // 创建结算记录
        const settlement = yield Settlement.create({
            bill_type,
            bill_id,
            settlement_date,
            amount,
            payment_method
        });
        // 更新对应单据的结算状态
        if (bill_type === 'purchase') {
            const purchase = yield Purchase.findByPk(bill_id);
            if (purchase) {
                yield purchase.update({ settlement_status: '已结' });
            }
        }
        else if (bill_type === 'sale') {
            const sale = yield Sale.findByPk(bill_id);
            if (sale) {
                yield sale.update({ settlement_status: '已结' });
            }
        }
        res.status(201).json(settlement);
    }
    catch (error) {
        res.status(500).json({ error: '创建结算记录失败' });
    }
}));
// 获取采购应付账单
router.get('/purchase-bills', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const bills = yield Purchase.findAll({
            where: { settlement_status: '未结' },
            include: [{ model: models_1.default.Supplier, as: 'Supplier' }]
        });
        res.json(bills);
    }
    catch (error) {
        res.status(500).json({ error: '获取应付账单失败' });
    }
}));
// 获取销售应收账款
router.get('/sale-bills', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const bills = yield Sale.findAll({
            where: { settlement_status: '未结' },
            include: [{ model: models_1.default.Customer, as: 'Customer' }]
        });
        res.json(bills);
    }
    catch (error) {
        res.status(500).json({ error: '获取应收账款失败' });
    }
}));
exports.default = router;
