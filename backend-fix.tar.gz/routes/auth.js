"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const models_1 = __importDefault(require("../models"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const svg_captcha_1 = __importDefault(require("svg-captcha"));
const router = express_1.default.Router();
const { User } = models_1.default;
// 生成验证码
router.get('/captcha', (req, res) => {
    const captcha = svg_captcha_1.default.create({
        size: 4,
        noise: 3,
        color: true,
        background: '#f0f0f0'
    });
    // 将验证码存储在会话中
    req.session = req.session || {};
    req.session.captcha = captcha.text.toLowerCase();
    res.type('svg');
    res.send(captcha.data);
});
// 登录
router.post('/login', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { username, password, captcha } = req.body;
        // 暂时禁用验证码验证，用于测试密码
        // if (!req.session || req.session.captcha !== captcha.toLowerCase()) {
        //   return res.json({ success: false, message: '验证码错误' });
        // }
        console.log('验证码验证已暂时禁用，直接测试用户名和密码');
        console.log('用户名:', username);
        console.log('密码:', password);
        // 查找用户
        const user = yield User.findOne({ where: { username } });
        if (!user) {
            console.log('用户不存在:', username);
            return res.json({ success: false, message: '用户名或密码错误' });
        }
        console.log('找到用户:', { id: user.id, username: user.username, password: user.password });
        // 验证密码
        console.log('开始验证密码...');
        const isPasswordValid = yield user.comparePassword(password);
        console.log('密码验证结果:', isPasswordValid);
        if (!isPasswordValid) {
            return res.json({ success: false, message: '用户名或密码错误' });
        }
        // 生成JWT令牌
        const token = jsonwebtoken_1.default.sign({ id: user.id, username: user.username, role: user.role }, 'your-secret-key', // 实际应用中应该使用环境变量
        { expiresIn: '24h' });
        // 清除验证码
        delete req.session.captcha;
        res.json({
            success: true,
            token,
            user: {
                id: user.id,
                username: user.username,
                name: user.name,
                role: user.role
            }
        });
    }
    catch (error) {
        console.error('登录失败:', error);
        res.json({ success: false, message: '登录失败，请稍后重试' });
    }
}));
// 退出登录
router.post('/logout', (req, res) => {
    // 清除会话
    req.session.destroy((error) => {
        if (error) {
            console.error('退出登录失败:', error);
            return res.json({ success: false, message: '退出登录失败' });
        }
        res.json({ success: true, message: '退出登录成功' });
    });
});
// 检查登录状态
router.get('/status', (req, res) => {
    var _a;
    try {
        const token = (_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.replace('Bearer ', '');
        if (!token) {
            return res.json({ success: false, message: '未登录' });
        }
        // 验证令牌
        const decoded = jsonwebtoken_1.default.verify(token, 'your-secret-key');
        res.json({ success: true, user: decoded });
    }
    catch (error) {
        res.json({ success: false, message: '登录已过期' });
    }
});
// 修改密码
router.post('/update-password', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        const token = (_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.replace('Bearer ', '');
        if (!token) {
            return res.json({ success: false, message: '未登录' });
        }
        // 验证令牌
        const decoded = jsonwebtoken_1.default.verify(token, 'your-secret-key');
        const { currentPassword, newPassword } = req.body;
        // 查找用户
        const user = yield User.findByPk(decoded.id);
        if (!user) {
            return res.json({ success: false, message: '用户不存在' });
        }
        // 验证原密码
        const isPasswordValid = yield user.comparePassword(currentPassword);
        if (!isPasswordValid) {
            return res.json({ success: false, message: '原密码错误' });
        }
        // 更新密码
        user.password = newPassword;
        yield user.save();
        res.json({ success: true, message: '密码修改成功' });
    }
    catch (error) {
        console.error('修改密码失败:', error);
        res.json({ success: false, message: '修改密码失败，请稍后重试' });
    }
}));
exports.default = router;
