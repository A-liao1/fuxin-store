"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const express_session_1 = __importDefault(require("express-session"));
const path_1 = __importDefault(require("path"));
const models_1 = require("./models");
const products_1 = __importDefault(require("./routes/products"));
const suppliers_1 = __importDefault(require("./routes/suppliers"));
const customers_1 = __importDefault(require("./routes/customers"));
const purchases_1 = __importDefault(require("./routes/purchases"));
const sales_1 = __importDefault(require("./routes/sales"));
const inventory_1 = __importDefault(require("./routes/inventory"));
const reports_1 = __importDefault(require("./routes/reports"));
const settlements_1 = __importDefault(require("./routes/settlements"));
const dashboard_1 = __importDefault(require("./routes/dashboard"));
const brands_1 = __importDefault(require("./routes/brands"));
const auth_1 = __importDefault(require("./routes/auth"));
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3001;
// 中间件
app.use((0, cors_1.default)({
    credentials: true,
    origin: ['http://localhost:5173', 'http://localhost:5174', 'https://tkvn.fun', 'http://104.223.59.170', 'https://104.223.59.170']
}));
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
// 信任代理（因为使用了nginx反向代理）
app.set('trust proxy', 1);
// 会话中间件
app.use((0, express_session_1.default)({
    secret: 'your-secret-key', // 实际应用中应该使用环境变量
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false, // nginx已处理HTTPS，后端接收的是HTTP
        httpOnly: true,
        sameSite: 'lax',
        maxAge: 1000 * 60 * 60 * 24 // 24小时过期
    }
}));
// 路由
app.use('/api/auth', auth_1.default);
app.use('/api/products', products_1.default);
app.use('/api/suppliers', suppliers_1.default);
app.use('/api/customers', customers_1.default);
app.use('/api/purchases', purchases_1.default);
app.use('/api/sales', sales_1.default);
app.use('/api/inventory', inventory_1.default);
app.use('/api/reports', reports_1.default);
app.use('/api/settlements', settlements_1.default);
app.use('/api/dashboard', dashboard_1.default);
app.use('/api/brands', brands_1.default);
// 静态文件服务
app.use(express_1.default.static('public'));
// 健康检查
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});
// 前端路由 fallback
app.use((req, res) => {
    res.sendFile(path_1.default.join(__dirname, '../public', 'index.html'));
});
// 数据库初始化
const initDatabase = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield models_1.sequelize.sync({ force: false });
        console.log('数据库初始化成功');
    }
    catch (error) {
        console.error('数据库初始化失败:', error);
        process.exit(1);
    }
});
// 启动服务器
const startServer = () => __awaiter(void 0, void 0, void 0, function* () {
    yield initDatabase();
    app.listen(PORT, () => {
        console.log(`服务器运行在 http://localhost:${PORT}`);
    });
});
startServer();
exports.default = app;
